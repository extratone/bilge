# WWDC21 Challenge: Speech Synthesizer Simulator

Simulate a conversation using speech synthesis.

## Overview

- Note: This is a companion project for WWDC21 Challenge [Speech Synthesizer Simulator](https://developer.apple.com/news/?id=ux4fipi2).
