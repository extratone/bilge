/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The dialogue label.
*/

import UIKit

class DialogueLabel: UILabel {
    @IBInspectable var cornerRadius: CGFloat = 15
}
