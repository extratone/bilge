# Adding Hardware Keyboard Support to Your App

Enhance interactions with your app by handling raw keyboard events, writing custom keyboard shortcuts, and working with gesture recognizers.

## Overview

- Note: This sample code project is associated with WWDC20 session [10109: Hardware Keyboard Best Practices](https://developer.apple.com/wwdc20/10109/).
