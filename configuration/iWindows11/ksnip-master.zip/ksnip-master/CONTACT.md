Welcome to the ksnip community.

Give and grant anyone constrictive criticism and their desired privacy.
Settle conflicts within these bounds.
Finding yourselves unable to do so, e-mail [Damir Porobić](email@damirporobic.me), the project maintainer.
