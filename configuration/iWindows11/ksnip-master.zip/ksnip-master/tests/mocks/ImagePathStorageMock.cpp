/*
 * Copyright (C) 2021 Damir Porobic <damir.porobic@gmx.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#include "ImagePathStorageMock.h"

void ImagePathStorageMock::store(const QString &value, int index)
{
	mStoreCallCounter.increment(index);
	mPathMap[index] = value;
}

QString ImagePathStorageMock::load(int index)
{
	return mPathMap[index];
}

int ImagePathStorageMock::count()
{
	return mPathMap.count();
}

int ImagePathStorageMock::store_callCounter(int index) const
{
	return mStoreCallCounter.count(index);
}
